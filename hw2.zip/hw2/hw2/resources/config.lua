--In this homework I used a look-at matrix.
--the world frame (0,0) is always at the
--center of screen
rotSpeed = 10
eye={ 10,10.0,10.0}
projection = {45.0,1.0,-0.1,-200.0}

--if you need to do other work, write them
--in the init() function
function init()
end
